document.addEventListener('DOMContentLoaded', () => {
  const supportForm = document.getElementById('supportEmailForm');
  const supportModalEl = document.getElementById('supportModal');
  const recipientEmail = 'hello@examplewebsite142.com';

  const contactCard = document.getElementById('contactSupportCard');
  if (contactCard) {
    contactCard.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        contactCard.click();
      }
    });
  }

  if (supportForm) {
    supportForm.addEventListener('submit', (event) => {
      event.preventDefault();

      const name = document.getElementById('senderName').value.trim();
      const subject = document.getElementById('emailSubject').value.trim();
      const message = document.getElementById('emailMessage').value.trim();

      const formattedBody = `Hi OURA Support Team,\n\n${message}\n\nBest regards,\n${name}`;
      const mailtoUrl = `mailto:${encodeURIComponent(recipientEmail)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(formattedBody)}`;

      window.location.href = mailtoUrl;

      const modalInstance = bootstrap.Modal.getInstance(supportModalEl);
      if (modalInstance) {
        modalInstance.hide();
      }
    });
  }
});